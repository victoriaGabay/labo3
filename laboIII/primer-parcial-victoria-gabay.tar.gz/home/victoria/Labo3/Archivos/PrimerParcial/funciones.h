#ifndef _FUNCIONES
#define _FUNCIONES

int obtenerNumeroAleatorio(int desde, int hasta);
char *getFileName(int menu);
int getMenuType(char menu[]);
int getMenuPrice(int menu);
char *getMenu(int menu);

#endif
