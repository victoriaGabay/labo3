#ifndef _DEFINICIONES_H
#define _DEFINICIONES_H

#define LEN 100
#define CLAVE_BASE 1
#define ROJO 0
#define VERDE 1
#define LARGO 100
#define DESDE 1
#define HASTA 4
#define TARGET 5

#endif
