#include "stdlib.h"
#include "stdio.h"
#include "memoria.h"
#include "clave.h"
#include <sys/shm.h>
#include "unistd.h"
#include "sys/ipc.h"
#include "definiciones.h"

void* crearMemoria(int size, int* r_id_memoria, int key)
{
	void* ptr_memoria;
	int idMemoria;
	idMemoria = shmget (creoClave(CLAVE_BASE), size, 0777 | IPC_CREAT);
	
	if(idMemoria == -1)
	{
		printf("No se pudo crear un id para memoria compartida \n");
		return 0;
	}
	
	ptr_memoria = (void *)shmat (idMemoria, (char *)0, 0);

	if(ptr_memoria == NULL)
	{
		printf("No se encontro memoria compartida \n");
		return 0;
	}

	*r_id_memoria = idMemoria;

	return ptr_memoria;
}
