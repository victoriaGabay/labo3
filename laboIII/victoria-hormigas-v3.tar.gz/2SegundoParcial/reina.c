#include "stdlib.h"
#include "stdio.h"
#include "memoria.h"
#include "definiciones.h"
#include "global.h"
#include "time.h"
#include "unistd.h"
#include <sys/shm.h>
#include "string.h"
#include "colas.h"

typedef struct Data data;
typedef struct DatosReina datosReina;
int idColaMensajes;
int cantHormigas;
pthread_mutex_t mutex;

void notificar(int idCola, int cantHormigas, int accion)
{
	int i;
	char mensaje[2];
	
	memset(mensaje, 0x00, sizeof(mensaje));
	for(i = 0; i < cantHormigas; i++)
	{	
		sprintf(mensaje, "%d", accion);
		enviarMensaje(idCola, MSG_OBRERA+i,MSG_REINA, EVT_JUNTAR, mensaje); 	
	}
}

void handleMenu()
{
	int accion = 0, continuo = 1, insumosHormiga;
	datosReina datos;
	mensaje msg;
	
	datos.total = 0;
	datos.totalPalitos = 0;
	datos.totalPiedras = 0;
	datos.totalHojas = 0;
	datos.totalComida = 0;

	while(continuo)
	{	
		printf("Seleccione el insumo a juntar \n");
		printf("0. Palitos \n");
		printf("1. Piedras \n");
		printf("2. Hojas \n");
		printf("3. Comida \n");
		scanf("%d", &accion);
		notificar(idColaMensajes, cantHormigas, accion);

		recibirMensaje(idColaMensajes, MSG_REINA, &msg);
		switch (msg.event)
		{
			case EVT_FIN: 
				printf("Todas las hormigas han terminado. \n");
				continuo = 0;
				break;
			case EVT_FIN_PARTICULAR:
				printf("La hormiga %d ha finalizado su trabajo. \n", msg.rte);
				break;
			case EVT_CONTINUO:
				sscanf(msg.msg, "%d", &insumosHormiga);
				switch(accion)
				{	
					case Palitos: 
						datos.totalPalitos = datos.totalPalitos + insumosHormiga; 
						break;
					case Piedras:
						datos.totalPiedras = datos.totalPiedras + insumosHormiga; 
						break;
					case Hojas:	
						datos.totalHojas = datos.totalHojas + insumosHormiga; 
						break;	
					case Comida:
						datos.totalComida = datos.totalComida + insumosHormiga; 
						break;
				}
				

		}
		datos.total = datos.totalPalitos + datos.totalPiedras + datos.totalHojas + datos.totalComida;
		printf("Se han recolectado %d palitos. \n", datos.totalPalitos);
		printf("Se han recolectado %d piedras. \n", datos.totalPiedras);	
		printf("Se han recolectado %d hojas. \n", datos.totalHojas);	
		printf("Se han recolectado %d comida. \n", datos.totalComida);	
		printf("Total de insumos recolectados %d \n", datos.total); 
	}
}

int main(int incant, char *szarg[])
{
	int idMemoria;
	data *memoria = NULL;

	cantHormigas = 0;
	if(szarg[1])
	{
		cantHormigas = atoi(szarg[1]);
	}

	idColaMensajes = creoIdColaMensajes(CLAVE_BASE);
	borrarMensajes(idColaMensajes);
	memoria = (data*)crearMemoria(sizeof(data), &idMemoria, CLAVE_BASE);
	
	if(memoria[0].cantidadHormigas == 0)
	{
		memoria[0].cantidadHormigas = cantHormigas;
	}

	handleMenu(idColaMensajes, cantHormigas);

	shmdt((char *)memoria);
	shmctl(idMemoria, IPC_RMID, (struct shmid_ds *)NULL);
	return 0;
}
