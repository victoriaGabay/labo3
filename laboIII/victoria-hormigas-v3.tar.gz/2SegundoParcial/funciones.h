#ifndef _FUNCIONES
#define _FUNCIONES

int obtenerNumeroAleatorio(int desde, int hasta);
char *getInsumo(int menu);

#endif
