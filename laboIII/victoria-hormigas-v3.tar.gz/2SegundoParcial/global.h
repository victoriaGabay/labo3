#ifndef _GLOBAL	
#define _GLOBAL	

#include "stdio.h"
#include "stdlib.h"

typedef enum{
	MSG_NADIE,
	MSG_REINA,
	MSG_OBRERA
}Destinos;

typedef enum{
	EVT_NONE,
	EVT_JUNTAR,
	EVT_CONTINUO,
	EVT_FIN_PARTICULAR,
	EVT_FIN
} Eventos;

typedef enum{
	Palitos,
	Piedras,
	Hojas,
	Comida
} Insumos;

struct Jugador 
{
	int pasos;
	int id;
	int tiempoPasos;
};

struct Data
{
	int cantidadHormigas;
	int leido; 
};

typedef struct Hormiga
{
	int id;
	int cantPalitos;
	int cantHojas;
	int cantComida;
	int cantPiedras;
} hormiga ;

struct DatosReina 
{
	int totalPalitos;
	int totalHojas;
	int totalComida;
	int totalPiedras;
	int total;
};

#endif
