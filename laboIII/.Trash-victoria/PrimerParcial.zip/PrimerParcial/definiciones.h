#ifndef _DEFINICIONES_H
#define _DEFINICIONES_H

#define FILE_1 "menuA.txt"
#define FILE_2 "menuB.txt"
#define FILE_3 "menuC.txt"
#define LEN 100
#define CLAVE_BASE 1
#define ROJO 0
#define VERDE 1
#define DESDE 100
#define HASTA 500
#define ESPERA 100
#define MENU_FORMAT "%s\t%d\t%d\n"
#define OUT_FORMAT "%d\t%d\t%s\n"


#endif
