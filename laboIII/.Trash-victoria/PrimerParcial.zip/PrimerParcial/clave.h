#ifndef _CLAVE
#define _CLAVE

#include <sys/ipc.h>

key_t creoClave(int r_clave);

#endif
