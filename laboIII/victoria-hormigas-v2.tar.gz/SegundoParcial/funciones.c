#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "global.h"

int obtenerNumeroAleatorio(int desde, int hasta){

	return (rand()%(hasta-desde+1))+desde;
}

char *getInsumo(int menu)
{
	switch(menu){
		case Palitos:
			return "palitos"; break;
		case Piedras:
			return "piedras"; break;
		case Hojas: 
			return "hojas"; break;	
		case Comida: 
			return "Comida"; break;	
	
	}
	return "";
}
/*
int getMenuType(char menu[])
{

	if(strcmp(menu, "A") == 0)
	{
		return 1;
	}
	else if(strcmp(menu, "B") == 0)
	{
		return 2;
	}
	else if(strcmp(menu, "C") == 0)
	{
		return 3;
	}

	return 0;
}

int getMenuPrice(int menu)
{
	switch(menu){
		case 1:
			return 1000; break;
		case 2:
			return 2000; break;
		case 3: 
			return 3000; break;	
	
	}
	return 0;
}

char *getMenu(int menu)
{
	switch(menu){
		case 1:
			return "A"; break;
		case 2:
			return "B"; break;
		case 3: 
			return "C"; break;	
	
	}
	return "";
}*/
