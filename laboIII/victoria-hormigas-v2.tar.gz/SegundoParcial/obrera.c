#include "stdlib.h"
#include "stdio.h"
#include "global.h"
#include "definiciones.h"
#include "colas.h"
#include "pthread.h"
#include "funciones.h"
#include "string.h"
#include "memoria.h"
#include <sys/shm.h>
#include "time.h"
#include "unistd.h"

void notificar(int idCola, hormiga *h)
{
	char mensaje[200];
	char cadena[50];
	sprintf(mensaje, "%d", h->id);
	enviarMensaje(idCola, MSG_REINA, MSG_OBRERA, EVT_FIN_PARTICULAR, "pepe"); 	
}

pthread_mutex_t mutex;
int idColaMensajes;
void *obrerasThread(void *param)
{
	hormiga *h = (hormiga *)param;
	mensaje msg;
	char tipo[100];
	int insumo = 0, cantidad;
	while(1)
	{
		pthread_mutex_lock(&mutex);
		memset(tipo, 0x00, sizeof(tipo));
		recibirMensaje(idColaMensajes, h->id, &msg);		
		sscanf(msg.msg, "%d", &insumo);
		
		if(h->cantPalitos > TARGET || h->cantHojas > TARGET || h->cantComida > TARGET || h->cantPiedras > TARGET)
		{
			notificar(idColaMensajes, h);
			pthread_mutex_unlock(&mutex);
			break;
		}
		else
		{	
			cantidad = obtenerNumeroAleatorio(DESDE, HASTA);
			strcpy(tipo, getInsumo(insumo));
			printf("La hormiga %d recolecto %d %s\n",h->id, cantidad, tipo);
			switch(insumo){
				case Palitos:
					 h->cantPalitos = h->cantPalitos+cantidad; 
					printf("La hormiga %d recolecto en total %d %s\n",h->id, h->cantPalitos, tipo);
					break;
				case Piedras:
					 h->cantPiedras = h->cantPiedras+cantidad;
					printf("La hormiga %d recolecto en total %d %s\n",h->id, h->cantPiedras, tipo); 
					break;
				case Hojas: 
					 h->cantHojas = h->cantHojas+cantidad; 
					printf("La hormiga %d recolecto en total %d %s\n",h->id, h->cantHojas, tipo); 
					break;	
				case Comida: 
					 h->cantComida = h->cantComida+cantidad; 
					printf("La hormiga %d recolecto en total %d %s\n",h->id, h->cantComida, tipo); 
					break;	
			}
		}
		pthread_mutex_unlock(&mutex);
		usleep(10000);
	}
	pthread_exit((void *)"Listo");
}

int main(int incant, char *szarg[])
{
	int continuo = 1, idMemoria, i, cantidad;
	mensaje msg;
	pthread_t * idThread;
	pthread_attr_t atributos;
	hormiga *thread;
	char mensajeFin[200];

	datos *memoria= NULL;
	memoria = (datos*)crearMemoria(sizeof(datos), &idMemoria, CLAVE_BASE);
	
	cantidad = memoria[0].cantidadHormigas;
	idColaMensajes = creoIdColaMensajes(CLAVE_BASE);

	thread = (hormiga*)malloc(sizeof(hormiga)*cantidad);	
	idThread = (pthread_t *) malloc(sizeof(pthread_t)*cantidad);
	pthread_attr_init (&atributos);
	pthread_attr_setdetachstate(&atributos, PTHREAD_CREATE_JOINABLE);
	pthread_mutex_init(&mutex, NULL);

	for(i = 0; i < cantidad; i++)
	{
		thread[i].id = MSG_OBRERA+i;
		thread[i].cantPalitos = 0;
		thread[i].cantHojas = 0;
		thread[i].cantComida = 0;
		thread[i].cantPiedras = 0;
		pthread_create(&idThread[i], &atributos, obrerasThread, &thread[i]);	
	}
	
	for(i = 0; i < cantidad; i++)
	{	
		pthread_join(idThread[i], NULL);
	}

	strcpy(mensajeFin, "todas las hormigas terminaron");
	enviarMensaje(idColaMensajes, MSG_REINA, MSG_OBRERA, EVT_FIN, mensajeFin); 
	pthread_mutex_destroy(&mutex);
	shmdt((char *)memoria);
	shmctl(idMemoria, IPC_RMID, (struct shmid_ds *)NULL);
	return 0;
}
