#ifndef _GLOBAL	
#define _GLOBAL	

#include "stdio.h"
#include "stdlib.h"

typedef struct Hormiga
{
	int id;
	int cantPalitos;
	int cantHojas;
	int cantComida;
	int cantPiedras;
} hormiga ;

typedef enum{
	MSG_NADIE,
	MSG_REINA,
	MSG_OBRERA
}Destinos;

typedef enum{
	EVT_NONE,
	EVT_JUNTAR,
	EVT_FIN_PARTICULAR,
	EVT_FIN
} Eventos;

typedef enum{
	Palitos,
	Piedras,
	Hojas,
	Comida
} Insumos;

typedef struct Datos
{
	int cantidadHormigas;
	int idHormigaTermino;
} datos;

typedef struct Prueba 
{
	int *fin;
} prueba;

#endif
