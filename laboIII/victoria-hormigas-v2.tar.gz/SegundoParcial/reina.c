#include "stdlib.h"
#include "stdio.h"
#include "global.h"
#include "definiciones.h"
#include "colas.h"
#include "pthread.h"
#include "funciones.h"
#include "string.h"
#include "time.h"
#include "memoria.h"
#include <sys/shm.h>
#include "unistd.h"

pthread_mutex_t mutex;
int idColaMensajes;
int fin;

void notificar(int idCola, int cantHormigas, int accion)
{
	int i;
	char mensaje[2];
	
	memset(mensaje, 0x00, sizeof(mensaje));
	for(i = 0; i < cantHormigas; i++)
	{	
		sprintf(mensaje, "%d", accion);
		enviarMensaje(idCola, MSG_OBRERA+i,MSG_REINA, EVT_JUNTAR, mensaje); 	
	}
}

void *eventosThread(void *param)
{
	prueba *h = (prueba *)param;
	mensaje msg;
	char mensajestring[200];
	int insumo = 0, cantidad, idFin;

	while(1)
	{
		pthread_mutex_lock(&mutex);
		memset(mensajestring, 0x00, sizeof(mensajestring));
		recibirMensaje(idColaMensajes, MSG_REINA, &msg);
		
		if(msg.event == EVT_FIN)
		{	
			printf("Todas las hormigas han terminado. \n");
			pthread_mutex_unlock(&mutex);
			break;
		}
		else
		{
			sscanf(msg.msg, "%d", &idFin);
			printf("La hormiga %d ha finalizado su trabajo. \n", idFin);
		}
		pthread_mutex_unlock(&mutex);
		usleep(10000);
	}

	pthread_exit((void *)"Listo");
}

int main(int incant, char *szarg[])
{
	int idMemoria, cantHormigas = 0, continuo = 0, accion, i;
	mensaje msg;
	pthread_t * idThread;
	pthread_attr_t atributos;
	prueba *thread;
	datos *memoria= NULL;
	memoria = (datos*)crearMemoria(sizeof(datos), &idMemoria, CLAVE_BASE);
	
	
	pthread_mutex_init(&mutex, NULL);

	if(szarg[1])
	{
		cantHormigas = atoi(szarg[1]);
		memoria[0].cantidadHormigas = cantHormigas;
	}

	idColaMensajes = creoIdColaMensajes(CLAVE_BASE);
	borrarMensajes(idColaMensajes);
	
	thread = (prueba*)malloc(sizeof(prueba)*1);	
	idThread = (pthread_t *) malloc(sizeof(pthread_t)*cantHormigas);
	pthread_attr_init (&atributos);
	pthread_attr_setdetachstate(&atributos, PTHREAD_CREATE_JOINABLE);
	
	thread[0].fin = &continuo;
	pthread_create(&idThread[0], &atributos, eventosThread, &thread[0]);	
	
	while(!continuo)
	{	
		printf("Continuo: %d \n", continuo);
		printf("Seleccione el insumo a juntar \n");
		printf("0. Palitos \n");
		printf("1. Piedras \n");
		printf("2. Hojas \n");
		printf("3. Comida \n");
		scanf("%d", &accion);
		notificar(idColaMensajes, cantHormigas, accion);
	}

	pthread_mutex_destroy(&mutex);
	shmdt((char *)memoria);
	shmctl(idMemoria, IPC_RMID, (struct shmid_ds *)NULL);
	
	return 0;
}
