#ifndef _DEFINICIONES_H
#define _DEFINICIONES_H

#define LEN 100
#define CLAVE_BASE 12
#define ROJO 0
#define VERDE 1
#define LARGO 1
#define DESDE 1
#define HASTA 4
#define TARGET 5
#define HORMIGAS 5

#endif
