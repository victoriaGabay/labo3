#ifndef _COLAS
#define _COLAS

#include "definiciones.h"

typedef struct mensajes mensaje;
struct mensajes
{
	long dest;
	int rte;
	int event;
	char msg[LARGO];
};

int creoIdColaMensajes(int);
int borrarMensajes(int);
int recibirMensaje(int, long, mensaje*);
int enviarMensaje(int, long, int, int, char*);



#endif
