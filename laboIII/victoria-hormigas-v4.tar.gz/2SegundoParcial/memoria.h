#ifndef _MEMORIA
#define _MEMORIA

void* crearMemoria(int size, int* r_id_memoria, int key);

#endif
