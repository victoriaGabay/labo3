#ifndef _clave
#define _clave
#include "stdio.h"
#include "stdlib.h"    

#define ROJO	0
#define VERDE	1

key_t creo_clave();


#endif

