#ifndef _memoria
#define _memoria
#include "stdio.h"
#include "stdlib.h"    

#define ROJO	0
#define VERDE	1

void* creo_memoria(int size, int* r_id_memoria, int clave_base);


#endif

