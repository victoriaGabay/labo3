#ifndef _GLOBAL	
#define _GLOBAL	

#include "stdio.h"
#include "stdlib.h"

typedef enum{
	MSG_NADIE,
	MSG_JUG_EQUIPO_1,
	MSG_JUG_EQUIPO_2
}Destinos;

typedef enum{
	EVT_NONE,
	EVT_PATEA,
	EVT_RESULTADO_TIRO,
	EVT_FIN	
} Eventos;

typedef enum {
	ARQUERO,
	DEFENSOR,
	DELANTERO
} tipos;

typedef struct Datos
{
	int equipo1Listo;
	int equipo2Listo;
	int primerEquipo;
} datos;

typedef struct Jugador
{
	int equipo;
	int id;
	int tipo;
	int empieza;
	int *puedeTirar;
	int *golesEquipo;
	int *alguienEstaPateando;
} jugador;

#endif
