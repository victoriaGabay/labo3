#ifndef _FUNCIONES
#define _FUNCIONES

#include "global.h"

int obtenerNumeroAleatorio(int desde, int hasta);
int getTipo(int id);
char *getTipoJug(int id);
#endif
