#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "global.h"

int obtenerNumeroAleatorio(int desde, int hasta){

	return (rand()%(hasta-desde+1))+desde;
}

int getTipo(int id)
{
	switch(id)
	{
		case 0: return ARQUERO; break;
		case 1: return DEFENSOR; break;
		case 2: return DELANTERO; break;
		case 3: return DEFENSOR; break;
		case 4: return DELANTERO; break;
	}
	return 0;

}

char *getTipoJug(int id)
{
	switch(id)
	{
		case ARQUERO: return "Arquero"; break;
		case DEFENSOR: return "Defensor"; break;
		case DELANTERO: return "Delantero"; break;
	}
	return "";

}
